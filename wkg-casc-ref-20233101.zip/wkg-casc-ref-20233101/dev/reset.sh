sh des.sh
sh setup.sh
