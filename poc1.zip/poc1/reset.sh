sh destroy.sh
# sleep 30
sh setup.sh
